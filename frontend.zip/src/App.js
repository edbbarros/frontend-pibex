import React from 'react';
import 'materialize-css/dist/js/materialize.min.js'
import 'materialize-css/dist/js/materialize'
import './teste/style.css'
import './login/style.css'
import 'materialize-css'
import { Routes } from './routes';



function App() {
  return (
      <div className="App">
        <Routes/>
      </div>
  );
}  


export default App;
 